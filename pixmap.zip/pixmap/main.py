import test
from PyQt6 import QtWidgets
from PyQt6 import QtGui
from PyQt6.QtWidgets import QMainWindow, QHBoxLayout, QLabel
from PyQt6.QtCore import Qt, QByteArray, QRect
from PyQt6.QtGui import QImage, QPixmap, QIcon
from test import *
import MySQLdb as mdb

class MainWindow(QtWidgets.QWidget):
    def __init__(self, parent = None):
        super(MainWindow, self).__init__(parent)
        self.setWindowTitle('Магазин')
        res_data = test.get_data_2()
        height = 10
        for i in res_data:
            j = 1
            img = i[4]

            qimage = QImage.fromData(QByteArray(img))
            qpixmap = QPixmap.fromImage(qimage)
            file_path = f"save_img/{j}.jpg"
            qpixmap.save(file_path, "JPG")
            
            lb = QLabel(self)
            lb.setGeometry(QRect(100, height, 180, 150))
            lb.setAlignment(Qt.AlignmentFlag.AlignLeft)
            lb.setText("")
            lb.setPixmap(QtGui.QPixmap(f"save_img/{j}.jpg"))
            lb.setObjectName(f"{j}")

            lb_t = QLabel(self)
            lb_t.setGeometry(QRect(200, height, 210, 150))
            lb_t.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lb_t.setText(f"Название: {i[0]} \n Цена: {i[1]} \n Количество в корзине: {i[2]} \n Дата: {i[3]}\n")
            lb_t.setObjectName(f"{j}")
            break


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    wind = MainWindow()
    wind.show()
    sys.exit(app.exec())







