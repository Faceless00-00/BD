import MySQLdb as mdb

conn = mdb.connect('localhost','root','','pybd')

def get_data():
    cursor = conn.cursor()
    cursor.execute("Call GetCartSummary()")
    res = cursor.fetchall()
    return res

def get_data_2():
    cursor = conn.cursor()
    cursor.execute("Call GetCustomerCartInfoWithImage(\"Smith\");")
    res = cursor.fetchall()
    return res