-- Создание бд
CREATE DATABASE IF NOT EXISTS NetworkEquipmentDB;
USE NetworkEquipmentDB;

-- Создание табличек
CREATE TABLE IF NOT EXISTS Devices (
    device_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    price DECIMAL(10, 2),
    quantity INT,
    sold INT,
	img MEDIUMBLOB NULL
);
CREATE TABLE IF NOT EXISTS Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    order_date DATE,
    total_amount DECIMAL(10, 2)
);
CREATE TABLE IF NOT EXISTS OrderPositions (
    position_id INT AUTO_INCREMENT PRIMARY KEY,
    device_id INT,
    order_id INT,
    order_date DATETIME,
    quantity INT,
    FOREIGN KEY (device_id) REFERENCES Devices(device_id)
	FOREIGN KEY (order_id) REFERENCES Orders(order_id)
);



-- Вставка тестовых данных
INSERT INTO Devices (name, price, quantity, sold) VALUES
('Router', 100.00, 10, 2),
('Switch', 80.00, 15, 3);

INSERT INTO Orders (order_date, total_amount) VALUES
('2024-03-15', 250.00),
('2024-03-14', 300.00);

INSERT INTO OrderPositions (device_id, order_id, order_date, quantity) VALUES
(1, 1, '2024-03-15 10:00:00', 2),
(2, 1, '2024-03-15 10:00:00', 3),
(1, 2, '2024-03-14 09:30:00', 4),
(2, 2, '2024-03-14 09:30:00', 5);





--первая хп
DELIMITER $$

CREATE PROCEDURE GetOrderSummary()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE order_id_var INT;
    DECLARE order_total DECIMAL(10, 2);
    DECLARE total_quantity INT;
    DECLARE cur_order CURSOR FOR SELECT DISTINCT order_id FROM OrderPositions;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur_order;
    
    order_loop: LOOP
        FETCH cur_order INTO order_id_var;
        IF done THEN
            LEAVE order_loop;
        END IF;
        
        SELECT order_id_var AS 'Order Number',
               SUM(dev.price * op.quantity) AS 'Order Amount',
               SUM(op.quantity) AS 'Total Quantity'
          INTO order_id_var, order_total, total_quantity
          FROM OrderPositions op
          JOIN Devices dev ON op.device_id = dev.device_id
         WHERE op.order_id = order_id_var;
         
        SELECT order_id_var, order_total, total_quantity;
    END LOOP;
    
    CLOSE cur_order;
END$$

DELIMITER ;





--вторая хп
DELIMITER $$

CREATE PROCEDURE GetOrderDetails(IN order_id_param INT)
BEGIN
    SELECT dev.name AS 'Device Name',
           dev.price AS 'Price',
           op.quantity AS 'Quantity',
           op.order_date AS 'Order Date',
           dev.img AS 'Image'
      FROM OrderPositions op
      JOIN Devices dev ON op.device_id = dev.device_id
     WHERE op.order_id = order_id_param;
END$$

DELIMITER ;